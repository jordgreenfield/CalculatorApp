package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText input;
    float valueOne, valueTwo;
    boolean multiply, plus, minus, divide;//<-------- USE FOR OTHER APP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        defineButtons();
        input = (EditText) findViewById(R.id.input);

    }
    public void defineButtons(){
        findViewById(R.id.button0).setOnClickListener(buttonClickListener);
        findViewById(R.id.button1).setOnClickListener(buttonClickListener);
        findViewById(R.id.button2).setOnClickListener(buttonClickListener);
        findViewById(R.id.button3).setOnClickListener(buttonClickListener);
        findViewById(R.id.button4).setOnClickListener(buttonClickListener);
        findViewById(R.id.button5).setOnClickListener(buttonClickListener);
        findViewById(R.id.button6).setOnClickListener(buttonClickListener);
        findViewById(R.id.button7).setOnClickListener(buttonClickListener);
        findViewById(R.id.button8).setOnClickListener(buttonClickListener);
        findViewById(R.id.button9).setOnClickListener(buttonClickListener);
        findViewById(R.id.multiplyButton).setBackgroundColor(getResources().getColor(R.color.black));
        findViewById(R.id.multiplyButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.plusButton).setBackgroundColor(getResources().getColor(R.color.black));
        findViewById(R.id.plusButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.minusButton).setBackgroundColor(getResources().getColor(R.color.black));
        findViewById(R.id.minusButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.divideButton).setBackgroundColor(getResources().getColor(R.color.black));
        findViewById(R.id.divideButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.equalsButton).setBackgroundColor(getResources().getColor(R.color.black));
        findViewById(R.id.equalsButton).setOnClickListener(buttonClickListener);

        findViewById(R.id.resetButton).setBackgroundColor(getResources().getColor(R.color.teal_200));
        findViewById(R.id.resetButton).setOnClickListener(buttonClickListener);

    }

    public View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            switch (view.getId()){
                case R.id.button0:
                    input.setText(input.getText() + "0");
                    break;

                case R.id.button1:
                    input.setText(input.getText() + "1");
                    break;

                case R.id.button2:
                    input.setText(input.getText() + "2");
                    break;

                case R.id.button3:
                    input.setText(input.getText() + "3");
                    break;

                case R.id.button4:
                    input.setText(input.getText() + "4");
                    break;

                case R.id.button5:
                    input.setText(input.getText() + "5");
                    break;

                case R.id.button6:
                    input.setText(input.getText() + "6");
                    break;

                case R.id.button7:
                    input.setText(input.getText() + "7");
                    break;

                case R.id.button8:
                    input.setText(input.getText() + "8");
                    break;

                case R.id.button9:
                    input.setText(input.getText() + "9");
                    break;

                case R.id.multiplyButton:
                    valueOne = Float.parseFloat(input.getText()+ "");//parse float turn then + "" turns it into a string
                    multiply = true;
                    input.setText(null);
                    break;

                case R.id.plusButton:
                    if (input == null){
                        input.setText("");
                    }else {
                        valueOne = Float.parseFloat(input.getText() +"");
                        plus = true;
                        input.setText(null);
                    }
                    break;

                case R.id.minusButton:
                    valueOne = Float.parseFloat(input.getText()+ "");
                    minus = true;
                    input.setText(null);
                    break;

                case R.id.divideButton:
                    valueOne = Float.parseFloat(input.getText()+ "");
                    divide = true;
                    input.setText(null);
                    break;

                case R.id.equalsButton://CAN USE THIS METHOD FOR ADDING, SUBTRACTING AND UPDATING INFO IN AN APP  <-------------- (see top for boolean variables)
                    valueTwo = Float.parseFloat(input.getText()+ "");
                    if (plus == true){
                        input.setText(valueOne + valueTwo + "");//"" turns it into a string?
                        plus = false;
                    }

                    if (multiply == true){
                        input.setText(valueOne * valueTwo + "");
                        multiply = false;
                    }

                    if (minus == true){
                        input.setText(valueOne - valueTwo + "");
                        minus = false;
                    }

                    if (divide == true){
                        input.setText(valueOne / valueTwo + "");
                        divide = false;
                    }
                    break;

                case R.id.resetButton:
                    input.setText("");
                    break;

                default:
                    break;
            }
        }
    };
}